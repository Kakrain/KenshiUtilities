Kenshi Utilities — v1.0
Finds overrides of files and records between mods.

Installation:
1. Unzip the package to a folder of your choice.
2. Ensure KenshiCore.dll is present in the same folder as KenshiUtilities.exe.
3. Run KenshiUtilities.exe 

Usage:
1. Select Search for File Overrides or Search for Mod Overrides.
2. After the comparison completes, click on a mod to see all conflicts between that mod and others.
3. Use this information to manage or resolve mod conflicts as needed.
